=====
Usage
=====

Start by importing Example.

.. code-block:: python

    import example
