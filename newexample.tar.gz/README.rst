===============================
Example
===============================

.. image:: https://img.shields.io/travis/MFSJMenger/example.svg
        :target: https://travis-ci.org/MFSJMenger/example

.. image:: https://img.shields.io/pypi/v/example.svg
        :target: https://pypi.python.org/pypi/example


Example package for docs

* Free software: 3-clause BSD license
* Documentation: (COMING SOON!) https://MFSJMenger.github.io/example.

Features
--------

* TODO
