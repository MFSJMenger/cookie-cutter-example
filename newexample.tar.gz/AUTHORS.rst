=======
Credits
=======

Maintainer
----------

* Maximilian Menger <maximilian.menger@univie.ac.at>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
